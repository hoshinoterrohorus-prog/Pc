# PC Launcher (Windows 11 style)

Launcher Android bergaya Windows 11. Semua yang ada di layar (lock screen, desktop, taskbar, Start, widget, jendela, app bawaan)
ada di `app/src/main/assets/index.html`. Daftar aplikasi Android asli muncul di Start > All apps dan bisa dibuka.

Cara build: upload folder ini ke repo GitHub lalu buka tab Actions > "Build PC Launcher APK" > unduh artifact `PC-Launcher-apk`.
Atau buka di Android Studio dan Build > Build APK(s).

Setelah install: tekan Home, pilih "PC Launcher", lalu "Selalu".
Tombol Home saat launcher terbuka = buka/tutup menu Start. Tombol Back juga membuka menu Start.
